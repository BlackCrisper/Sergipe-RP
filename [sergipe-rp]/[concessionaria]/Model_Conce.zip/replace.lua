--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

txd = engineLoadTXD("conce.txd", 1905 )
engineImportTXD(txd, 1905)
dff = engineLoadDFF("conce.dff", 1905 )
engineReplaceModel(dff, 1905)
col = engineLoadCOL ( "conce.col" )
engineReplaceCOL ( col, 1905 )
engineSetModelLODDistance(1905, 5000000)

--- © Creditos da pagina postadora: DropMTA

--- © Discord DropMTA: https://discord.gg/GZ8DzrmxUV

--- Acesse nosso site de mods: https://www.dropmta.com.br/

