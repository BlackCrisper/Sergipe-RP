txd = engineLoadTXD("487.txd")
engineImportTXD(txd, 488)
dff = engineLoadDFF("487.dff", 488)
engineReplaceModel(dff, 488)



