-- Generated using GM2MC ( GTA:SA Models To MTA:SA Converter )

addEventHandler('onClientResourceStart',getResourceRootElement(getThisResource()),function () 
txd = engineLoadTXD ( 'newsvan.txd' ) 
engineImportTXD ( txd, 582 ) 
dff = engineLoadDFF('newsvan.dff', 582) 
engineReplaceModel ( dff, 582 )
end)
