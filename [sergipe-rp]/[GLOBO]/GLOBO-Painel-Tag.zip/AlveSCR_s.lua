--[[
















                                        ########  ##    ## 
                                        ##     ##  ##  ##  
                                        ##     ##   ####   
                                        ########     ##    
                                        ##     ##    ##    
                                        ##     ##    ##    
                                        ########     ##          



                    
                       ###    ##       ##     ## ########  ######   ######  ########  
                      ## ##   ##       ##     ## ##       ##    ## ##    ## ##     ## 
                     ##   ##  ##       ##     ## ##       ##       ##       ##     ## 
                    ##     ## ##       ##     ## ######    ######  ##       ########  
                    ######### ##        ##   ##  ##             ## ##       ##   ##   
                    ##     ## ##         ## ##   ##       ##    ## ##    ## ##    ##  
                    ##     ## ########    ###    ########  ######   ######  ##     ## 
















--]]


 function AlveSCR_openPanel(thePlayer)
 local accName = getAccountName(getPlayerAccount(thePlayer))
if isObjectInACLGroup("user."..accName, aclGetGroup("CMDGLOBO")) then
     triggerClientEvent(thePlayer, "abrirBP", getRootElement())
  end
end
addCommandHandler ("tagglobo", AlveSCR_openPanel)

function AlveSCR_add (thePlayer)
if isGuestAccount(getPlayerAccount(thePlayer)) then
outputChatBox ("#ff0000| ERRO | Este jogador(a) não está logado(a)!", source, 255,255,255, true)
else
    if not (isElement(thePlayer)) then return end
    local accountName = getAccountName(getPlayerAccount(thePlayer))
    if accountName then
	local login = getAccountName(getPlayerAccount(thePlayer))
if not isObjectInACLGroup("user."..login, aclGetGroup("RPT")) then
        aclGroupAddObject (aclGetGroup("RPT"), "user."..accountName)
        outputChatBox ("#0099cc| INFO | Você setou a TAG de Reporter para o(a) jogador(a) "..getPlayerName(thePlayer).."", source, 255, 255, 255, true)
		outputChatBox ("#0099cc| INFO | Parabens agora você faz parte do Globo!", thePlayer, 255, 255, 255, true)
	   
else
        outputChatBox ("#ff0000| ERRO | Este jogador(a) já está com essa TAG!", source, 255, 255, 255, true)
    end
    else
	outputChatBox ("#ff0000| ERRO | Selecione um(uma) jogador(a)!", source, 255, 255, 255, true)
end
end
end
addEvent( "addBP", true )
addEventHandler( "addBP", root, AlveSCR_add )

function AlveSCR_remove (thePlayer)
if isGuestAccount(getPlayerAccount(thePlayer)) then
outputChatBox ("#ff0000| ERRO | Este jogador(a) não está logado(a)!", source, 255,255,255, true)
else
    if not (isElement(thePlayer)) then return end
    local accountName = getAccountName(getPlayerAccount(thePlayer))
    if accountName then
	local login = getAccountName(getPlayerAccount(thePlayer))
if  isObjectInACLGroup("user."..login, aclGetGroup("RPT")) then
        aclGroupRemoveObject (aclGetGroup("RPT"), "user."..accountName)
        outputChatBox ("#0099cc| INFO | Você retirou a TAG de Reporter do(a) jogador(a) "..getPlayerName(thePlayer).."", source, 255, 255, 255, true)
		outputChatBox ("#0099cc| INFO | Agora você não faz mais parte do Globo!", thePlayer, 255, 255, 255, true)
else
        outputChatBox ("#ff0000| ERRO | Este jogador(a) não está com essa tag!", source, 255, 255, 255, true)
    end
else
	outputChatBox ("#ff0000| ERRO | Selecione um(uma) jogador(a)!", source, 255, 255, 255, true)
end
end
end
addEvent( "removeBP", true )
addEventHandler( "removeBP", root, AlveSCR_remove )