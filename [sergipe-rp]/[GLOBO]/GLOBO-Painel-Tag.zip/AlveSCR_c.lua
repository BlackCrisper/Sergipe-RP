--[[
















                                        ########  ##    ## 
                                        ##     ##  ##  ##  
                                        ##     ##   ####   
                                        ########     ##    
                                        ##     ##    ##    
                                        ##     ##    ##    
                                        ########     ##          



                    
                       ###    ##       ##     ## ########  ######   ######  ########  
                      ## ##   ##       ##     ## ##       ##    ## ##    ## ##     ## 
                     ##   ##  ##       ##     ## ##       ##       ##       ##     ## 
                    ##     ## ##       ##     ## ######    ######  ##       ########  
                    ######### ##        ##   ##  ##             ## ##       ##   ##   
                    ##     ## ##         ## ##   ##       ##    ## ##    ## ##    ##  
                    ##     ## ########    ###    ########  ######   ######  ##     ## 
















--]]

   AlveSCR_painel = guiCreateWindow(465, 307, 433, 341, "Tag Globo", false)
   guiWindowSetSizable(AlveSCR_painel, false)
   guiSetVisible(AlveSCR_painel, false)
   guiSetProperty(AlveSCR_painel, "NormalTextColour", "FF0099cc0")

   AlveSCR_glidlist = guiCreateGridList(9, 55, 230, 265, false, AlveSCR_painel)
   AlveSCR_text = guiGridListAddColumn(AlveSCR_glidlist, "#Players :", 0.9)

   AlveSCR_add = guiCreateButton(259, 83, 154, 60, "ADICIONAR", false, AlveSCR_painel)
   guiSetProperty(AlveSCR_add, "NormalTextColour", "FF0099cc0")

   AlveSCR_remove = guiCreateButton(259, 210, 154, 60, "REMOVER", false, AlveSCR_painel) 
   guiSetProperty(AlveSCR_remove, "NormalTextColour", "FF0099cc0")    



function AlveSCR_open()
  if guiGetVisible(AlveSCR_painel) then
    guiSetVisible(AlveSCR_painel, false)
    showCursor(false)
  else
    guiSetVisible(AlveSCR_painel, true)
  showCursor(true)
  AlveSCR_gridlist ()
  end
end
addEvent("abrirBP", true)
addEventHandler("abrirBP", getRootElement(), AlveSCR_open)



function AlveSCR_atualizar()
guiGridListClear(AlveSCR_glidlist)
for index, player in ipairs(getElementsByType("player")) do
 FILA = guiGridListAddRow(AlveSCR_glidlist)
 guiGridListSetItemText ( AlveSCR_glidlist, FILA, AlveSCR_text, (string.gsub ( getPlayerName(player), '#%x%x%x%x%x%x', '' ) or getPlayerName(player)), false, false)
 guiGridListSetItemData ( AlveSCR_glidlist, FILA, AlveSCR_text, getPlayerName(player))
end
end
addEventHandler("onClientPlayerJoin", getRootElement(), AlveSCR_atualizar)
addEventHandler("onClientPlayerQuit", getRootElement(), AlveSCR_atualizar)
addEventHandler("onClientPlayerChangeNick", getRootElement(), AlveSCR_atualizar)
addEventHandler ("onClientResourceStart",getRootElement(), AlveSCR_atualizar)


function AlveSCR_gridlist ()
  guiGridListClear(AlveSCR_glidlist)
  for i, thePlayer in ipairs ( getElementsByType ( "player" ) ) do
    local row = guiGridListAddRow( AlveSCR_glidlist )
    guiGridListSetItemText ( AlveSCR_glidlist, row, 1, getPlayerName( thePlayer ), false, false )
  end
end




function AlveSCR_adicionar ()
    local AlveSCR_jogador = guiGridListGetItemText(AlveSCR_glidlist, guiGridListGetSelectedItem(AlveSCR_glidlist), 1)
    triggerServerEvent("addBP", localPlayer, getPlayerFromName(AlveSCR_jogador))
end
addEventHandler ("onClientGUIClick", AlveSCR_add, AlveSCR_adicionar ,false)



function AlveSCR_remover ()
    local AlveSCR_jogador = guiGridListGetItemText(AlveSCR_glidlist, guiGridListGetSelectedItem(AlveSCR_glidlist), 1)
    triggerServerEvent("removeBP", localPlayer, getPlayerFromName(AlveSCR_jogador))
end
addEventHandler ("onClientGUIClick", AlveSCR_remove, AlveSCR_remover ,false)