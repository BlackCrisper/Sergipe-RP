function enterVehicle (player, seat, jacked) -- Chama a função ao jogador entrar no veículo
	local accName = getAccountName ( getPlayerAccount ( player ) ) -- Define o accName Abaixo
	if not isObjectInACLGroup("user."..accName, aclGetGroup ( "RPT" )) and getElementModel(source) == 582 then -- Define o Grupo e o id do veículo "411"
	cancelEvent()
		outputChatBox ( "[ERRO] *Você não é membro da Globo para pegar este veículo!", player ) --Manda uma mensagem se o jogador não estiver no grupo CONSOLE
	end
end
addEventHandler ( "onVehicleStartEnter", getRootElement(), enterVehicle ) -- Chama o evento Quando o jogador entra no carro