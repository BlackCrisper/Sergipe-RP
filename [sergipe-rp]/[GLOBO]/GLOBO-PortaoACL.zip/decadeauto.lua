﻿local gate = createObject(980, 1038.4000244141, -1998.0999755859, 14.699999809265, 0, 0, 265.5) 
local marker = createMarker(1038.4000244141, -1998.0999755859, 14.699999809265, "cylinder", 8, 0, 0, 0, 0) 
  
function moveGate(thePlayer) 
     if isObjectInACLGroup("user."..getAccountName(getPlayerAccount(thePlayer)) , aclGetGroup("RPT")) then 
          moveObject(gate, 300, 1038.4000244141, -1998.0999755859, 7.1999998092651) 
     end 
end 
addEventHandler("onMarkerHit", marker, moveGate) 
  
function move_back_gate() 
     moveObject(gate, 300, 1038.4000244141, -1998.0999755859, 14.699999809265) 
end 
addEventHandler("onMarkerLeave", marker, move_back_gate) 
